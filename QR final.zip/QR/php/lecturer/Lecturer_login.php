<?php

    $email = $_POST['email'];
    $pass = $_POST['password'];

    require_once '../db.php';

    // SQL query to fetch the user
    $sql = "SELECT * FROM lecturer WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Assuming passwords are not hashed
    $pwdCheck = password_verify($pass, $row['password']);
    if ($pwdCheck == true) {
        // Login successful
        session_start();
            $_SESSION['user_name'] = $row['name'];
            header("Location:Lecturer_Dashboard.php?stat=Login_successfully");
            exit();
    } else {
        // Invalid password
        header("Location: Lecturer.html?stat=Invalid_email_or_password");
    }
    } else {
    // Invalid username
    header("Location: Lecturer.html?stat=Invalid_email_or_password");
    }


?>
