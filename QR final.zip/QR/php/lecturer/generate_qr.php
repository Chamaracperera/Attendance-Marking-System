<?php
session_start();
// Check if the user is logged in
if (!isset($_SESSION['user_name'])) {
    header('Location:../../index.html?error=notloggedin');
    exit();
}
require '../vendor/autoload.php';  // If installed via Composer
include('../phpqrcode/qrlib.php'); // If manually downloaded
require_once '../db.php';
$domainURL = "http://localhost/attendance/QR/php/student";
if (isset($_POST["generate"])) {
    $qrcode = $_POST["subject"]."@";
    $qrcode .= implode('#', $_POST['batch']);
    $data = json_encode([
        'code' => $qrcode,
        'timestamp' => time(),
        'expiry' => 60 // Expiry duration in seconds (1 minute)
    ]);
    
    $qrcode = $domainURL."/verify_attendance.php?code=".urlencode($data);
    // Generate QR code and save it as an image
    QRcode::png($qrcode, 'qrcode.png', QR_ECLEVEL_H, 10);

    //echo $qrcode;
}
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="../../css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <span class="hamburger-btn material-symbols-rounded">menu</span>
            <a href="#" class="logo">
                <img src="../../img/logo.png" alt="logo">
                <h2>Attendance Marking System</h2>
            </a>
            
            <div class="navbar-right">
                <ul class="links">
                    <div class="profile">
                        <img src="../../img/user.png" class="profile-photo">
                        <span class="username"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </div>
                    <span class="close-btn material-symbols-rounded">close</span>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Help</a></li>
                </ul>
                <span class="notification-btn material-symbols-rounded">notifications</span>
                <button class="logout-btn" id="logoutBtn">LOGOUT</button>
            </div>
        </nav>
    </header>
    <div class="container">
        <div class="content">
<?php 
if (isset($_POST["generate"])) {
?>
            <form id="signup-form" action="#" method="POST">
                <div class="text">Scan QR Code</div>
                <img class='qrcode' src='qrcode.png' alt='QR Code'>
                <p>Expires in 60 seconds</p>
            </form>
<?php
} else {
?>
            <div id="form-message" class="form-message"></div>
            <form id="signup-form" action="generate_qr.php" method="POST">
                <div class="text">QR Code</div>
                <div class="field">
                    <select name="subject" required>
                        <option value="">Select Subject or Event</option>
    <?php 
    $sql = "SELECT * FROM subjects ORDER BY Subject_Code ASC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<option value='".$row['Subject_Code']."'>".$row['Subject_Code']." - ".$row['Subject_Name']."</option>";
        }
    }
    ?>
                    </select>
                    <span class="error-message"></span>
                </div>

                
    <?php 
    $sql1 = "SELECT * FROM batch ORDER BY year ASC";
    $stmt1 = $conn->prepare($sql1);
    if (!$stmt1) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    if ($result1->num_rows > 0) {
        while ($row1 = $result1->fetch_assoc()) {
            echo "<div class='show-password'>";
            echo "<input type='checkbox' name='batch[]' id='".$row1['year']."' value='".$row1['year']."'>";
            echo "<label for='".$row1['year']."'> ".$row1['year']."</label>";
            echo "</div>";
        }
    }
    ?>
                    <span class="error-message"></span>
                </div>
                <button name="generate" type="submit">Generate</button>
            </form>
<?php 
}
?>
        </div>
    </div>
    <script src="../../js/script_2.js"></script>
    <script>
    document.getElementById("logoutBtn").addEventListener("click", function () {
      alert("You have been logged out!");
      window.location.href = "../logout.php";
    });
  </script>
</body>
</html>
