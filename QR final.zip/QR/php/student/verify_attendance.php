<?php
session_start();
if (!isset($_SESSION['name'])) {
    header('Location:../../index.html?error=notloggedin');
    exit();
}
require_once '../db.php';

if (isset($_GET['code'])) {
    $data = json_decode(urldecode($_GET['code']), true);
    $studentId = $_SESSION['student_id'];
    $codeArray = explode('@', $data['code']);
    $subjectCode = $codeArray[0];
    $batchArray = explode('#', $codeArray[1]);
    $timestamp = $data['timestamp'];
    $expiry = $data['expiry'];

    if (time() - $timestamp <= $expiry) {
        $query = "SELECT * FROM subjects WHERE Subject_Code = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $subjectCode);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $subjectId = $row['Subject_id'];
        }

        $query1 = "SELECT * FROM batch WHERE batch_id = ?";
        $stmt1 = $conn->prepare($query1);
        $stmt1->bind_param("i", $_SESSION['batch_id']);
        $stmt1->execute();
        $res1 = $stmt1->get_result();
        if ($res1->num_rows > 0) {
            $row1 = $res1->fetch_assoc();
            $year = $row1['year'];
        }

        if (in_array($year, $batchArray)) {
            $tablename = str_replace(" ", "_", $subjectCode)."_attendance";
            $currentDate = date('Y-m-d'); // Date
            $currentTime = date('H:i:s'); // Time
            $insertQuery = "INSERT INTO $tablename (scanned_Date, scanned_Time, Subject_id, Subject_Code, student_id, batch_id) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("ssisii", $currentDate, $currentTime, $subjectId, $subjectCode, $studentId, $_SESSION['batch_id']);

            if ($stmt->execute()) {
                header("Location:Student_Dashboard.php?stat=User_Registration_Success");
            } else {
                header("Location:Student_Dashboard.php?stat=Error");
            }
        } else {
            header("Location:Student_Dashboard.php?stat=The_student's_batch_is_not_match");
        }
    } else {
        header("Location:Student_Dashboard.php?stat=qrcode_expepired");
    }
} else {
    header("Location:Student_Dashboard.php?stat=invalid_request");
}
?>